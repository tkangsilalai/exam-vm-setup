# ===============================
# Exam VM One-Shot Setup Script
# ===============================
# This script must be run as root.
# It will:
# 1) Lock down 'dsde' (remove sudo/admin and PolicyKit auto-admin)
# 2) Install WireGuard + Zenity + jq
# 3) Install and secure /usr/local/sbin/cp-vpn-setup.sh
# 4) Create sudoers rule allowing only that script (NOPASSWD)
# 5) Create & enable a systemd unit to run the script at boot
# 6) Install kafka_python_ng into the 'dsde' conda env

ROOT_PASS="1975"
STUDENT_USER="dsde"
VPN_SCRIPT_SRC="./cp-vpn-setup.sh"
VPN_SCRIPT_DEST="/usr/local/sbin/cp-vpn-setup.sh"
SUDOERS_DROPIN="/etc/sudoers.d/cp-vpn"
POLKIT_RULE="/etc/polkit-1/rules.d/49-nodesde.rules"
SERVICE_PATH="/etc/systemd/system/cp-vpn.service"

# ---------- sanity checks ----------
if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run as root (use sudo)." >&2
  exit 1
fi

if ! id -u "${STUDENT_USER}" >/dev/null 2>&1; then
  echo "ERROR: User '${STUDENT_USER}' does not exist." >&2
  exit 1
fi

echo "[1/9] Installing kafka_python_ng into the 'dsde' conda environment (if present)..."
# Activate conda for the student and install package. We try common conda init locations.
sudo -u "${STUDENT_USER}" bash -lc '
  set -e
  # Try standard conda activation path
  if [[ -f "$HOME/miniconda3/bin/activate" ]]; then
    source "$HOME/miniconda3/bin/activate"
    conda activate dsde 2>/dev/null || { echo "WARNING: conda env dsde not found."; exit 0; }
    pip install -q kafka_python_ng
    echo "kafka_python_ng installed in conda env dsde."
  else
    echo "WARNING: miniconda not found at ~/miniconda3. Skipping kafka_python_ng install."
  fi
'

echo "[2/9] Setting root password..."
echo "root:${ROOT_PASS}" | chpasswd

echo "[3/9] Removing '${STUDENT_USER}' from admin-capable groups (ignore errors if not present)..."
for grp in sudo adm lpadmin; do
  if getent group "$grp" >/dev/null; then
    deluser "${STUDENT_USER}" "$grp" >/dev/null 2>&1 || true
  fi
done

echo "[4/9] Disabling PolicyKit auto-admin (only root remains admin)..."
install -m 0755 -o root -g root -d "$(dirname "${POLKIT_RULE}")"
cat > "${POLKIT_RULE}" <<'EOF'
polkit.addAdminRule(function(action, subject) {
    return ["unix-user:0"]; // only root can admin
});
EOF
chmod 0644 "${POLKIT_RULE}"

echo "[5/9] Installing packages: wireguard, wireguard-tools, zenity, jq..."
apt-get update -y
DEBIAN_FRONTEND=noninteractive apt-get install -y wireguard wireguard-tools zenity jq curl

echo "[6/9] Installing VPN setup script to ${VPN_SCRIPT_DEST}..."
if [[ -f "${VPN_SCRIPT_SRC}" ]]; then
  mv -f "${VPN_SCRIPT_SRC}" "${VPN_SCRIPT_DEST}"
else
  # Also try a common alternate location if run from the same directory via root's cwd
  if [[ -f "./cp-vpn-setup.sh" ]]; then
    mv -f "./cp-vpn-setup.sh" "${VPN_SCRIPT_DEST}"
  else
    echo "WARNING: Could not find ${VPN_SCRIPT_SRC}. Creating a placeholder file."
    echo -e "#!/usr/bin/env bash\n echo 'cp-vpn-setup.sh placeholder. Replace with your real script.'\n" > "${VPN_SCRIPT_DEST}"
  fi
fi
chown root:root "${VPN_SCRIPT_DEST}"
chmod 700 "${VPN_SCRIPT_DEST}"

echo "[7/9] Creating sudoers drop-in to allow only this script (NOPASSWD) for ${STUDENT_USER}..."
cat > "${SUDOERS_DROPIN}" <<EOF
${STUDENT_USER} ALL=(root) NOPASSWD: ${VPN_SCRIPT_DEST}
EOF
# Validate sudoers syntax (will exit non-zero on error)
visudo -cf "${SUDOERS_DROPIN}" >/dev/null

echo "[8/9] Creating systemd service to run the VPN script at boot..."
cat > "${SERVICE_PATH}" <<EOF
[Unit]
Description=Run cp-vpn-setup.sh at boot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${VPN_SCRIPT_DEST}
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable cp-vpn.service

echo "[9/9] Attempting first run of the VPN setup script (this may open a GUI prompt in the student's session if configured to do so)..."
# Run once now (will succeed only if DISPLAY/XAUTHORITY are set inside the script as needed)
# If it needs GUI and none is available, it should exit gracefully.
sudo -u "${STUDENT_USER}" -H bash -lc "sudo ${VPN_SCRIPT_DEST}" || true

echo "-----------------------------------------"
echo "Setup COMPLETE."
echo "- Root password set."
echo "- '${STUDENT_USER}' stripped of sudo/admin."
echo "- PolicyKit restricted to root only."
echo "- WireGuard/Zenity/jq installed."
echo "- ${VPN_SCRIPT_DEST} installed, locked to root, runnable by ${STUDENT_USER} via sudo (NOPASSWD)."
echo "- systemd service cp-vpn.service enabled (runs at boot)."
echo "- kafka_python_ng attempted install into conda env 'dsde'."
echo "Reboot recommended now to apply PolicyKit changes."
echo "-----------------------------------------"


